package com.methods;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.testng.Assert;

import com.locators.Home_Page;
import com.utils.BaseClass;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class UserSearch extends BaseClass implements Home_Page{

	//Page Title verification
	public static void VerifyTitle(String Select){
	 String PageTitle = driver.getTitle();
		BaseClass.Browser(Select);
		assertEquals(PageTitle, "Sports Blog | Latest Football & Sports News | Betting tips - Unibet Blog");
	}
	
	public static void EmailFieldPresent(String email){
		boolean EmailFieldDisplayed = driver.findElement(Home_Page.Email_Field).isDisplayed();
		boolean EmailFieldEnabled = driver.findElement(Home_Page.Email_Field).isEnabled();
		if(EmailFieldDisplayed == true && EmailFieldEnabled == true){
			driver.findElement(Email_Field).sendKeys(email);
		}
	}
	
	public static void PasswordFieldPresent(String password){
		boolean PasswordFieldDisplayed = driver.findElement(Home_Page.Password_Field).isDisplayed();
		boolean PasswordFieldEnabled = driver.findElement(Home_Page.Password_Field).isEnabled();
		if(PasswordFieldDisplayed == true && PasswordFieldEnabled == true){
			driver.findElement(Password_Field).sendKeys(password);
		}
	}
	public static void LoginToApp(){
		boolean LoginButtonIsDispalyed = driver.findElement(LoginButton).isDisplayed();
		boolean LoginButtonIsEnabled = driver.findElement(LoginButton).isEnabled();
		if(LoginButtonIsDispalyed == true && LoginButtonIsEnabled == true){
			driver.findElement(LoginButton).click();
		}
	}
	
	public static void ClickOnSearchButton(){
		driver.findElement(SearchButton).click();
	}
	
	public static void MouseHoverOnSearch() throws InterruptedException{
		WebElement element = driver.findElement(SearchTextBox1);
        Actions action = new Actions(driver);
        action.moveToElement(element);
        action.click();
        Thread.sleep(1000);
        action.sendKeys("football");
        action.build().perform();
	}
	
	public static void GetGhostText(){
		String GhostText = driver.findElement(SearchTextBox1).getText();
		assertEquals(GhostText, "Search in blog");
	}
	
	public static void SearchBox2(){
		driver.findElement(SearchTextBox2).click();
	}
	
	public static void PerformSearch(String SearchText){
		driver.findElement(SearchTextBox2).sendKeys(SearchText);
	}
	
	public static void ClickOnSearchSuggetions(){
		
		List<WebElement> liElements = driver.findElements(SearchSuggetions);
        System.out.println(liElements);
        liElements.get(0).click();
      }
	
	public static void VerifySearchDetailsPage(){
		boolean SearchDetailPageDisplayed = driver.findElement(SearchResultDetails).isDisplayed();
		assertTrue(SearchDetailPageDisplayed);
      };	
	
	public static void DeleteSearchAndVeirfy(){
	boolean DeleteButotnDispalyed = driver.findElement(SearchDelete).isDisplayed();
	boolean DeleteButtonEnabled = driver.findElement(SearchDelete).isEnabled();
		if(DeleteButotnDispalyed == true && DeleteButtonEnabled == true){
		driver.findElement(SearchDelete).click();
		}
		String SearchFieldText = driver.findElement(SearchTextBox2).getText();
		assertEquals(SearchFieldText, "");
	}
	
	public static void VerifyNoSearchResults(){
		boolean NosearchResult = driver.findElement(NoSearchResult).isDisplayed();
		assertTrue(NosearchResult);
	}
	
	public static void SearchResultPage(){
		boolean SearchResultPage = driver.findElements(SearchResultList).isEmpty();
		assertFalse(SearchResultPage);
		
	}
}