package com.utils;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;

public class BaseClass {

public static WebDriver driver;
public static String pathtoChromedirver = "C:\\Nilesh\\Selenium\\chromedriver_win32\\chromedriver.exe";
public static String pathtoFirefoxdirver = "C:\\Nilesh\\Selenium\\geckodriver-v0.19.1-win64\\geckodriver.exe";

	//To select the browser from available list of browsers
	public static void Browser(String Select){
	/*BasicConfigurator.configure();*/
	
	switch(Select){
	case "chrome":
		System.setProperty("webdriver.chrome.driver", pathtoChromedirver);
		driver = new ChromeDriver();
		driver.navigate().to("https://www.unibet.co.uk/blog/search/");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		break;
		
	case "firefox":
		System.setProperty("webdriver.gecko.driver", pathtoFirefoxdirver);
		driver = new FirefoxDriver();

	}
}
	public static void Screenshot(WebDriver driver, String screenname){
		
		try {
			TakesScreenshot ts = (TakesScreenshot)driver;
			
			File SC = ts.getScreenshotAs(OutputType.FILE);
		
			FileHandler.copy(SC, new File("./ScreenShot/"+ screenname + ".png"));
		} catch (Exception e) {
			System.out.println("Exception while taking the screenshot");
		}
	}
	@AfterMethod //To take a screenshot of 
	public static void screenshot() throws AWTException, IOException{
		Robot robot = new Robot();
		BufferedImage img = robot.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
		ImageIO.write(img, "png", new File("C:\\Nilesh\\Selenium" + System.currentTimeMillis() + "test.png"));
		
	}
	
	@AfterMethod
	public static void CloseBrowser(){
		driver.close();
	}
}