package com.locators;

import org.openqa.selenium.By;

public interface Home_Page {

	
	public static By Email_Field = By.id("ufe_unique_id_1");				
	public static By Password_Field = By.id("ufe_unique_id_2");
	public static By SearchBox = By.id("icon-search");
	public static By SearchTextBox1 = By.className("_2wd9gLhmkYlXBxVhBXNH6i");
	public static By SearchTextBox2 = By.className("_3Hr3qONzU09D2EpcszWrzd");
	//public static By SearchTextBox2 = By.xpath("/html/body/div[2]/div[5]/div[3]/div/div/div/div/div/div/div/div[2]/div/div[2]/div/div[1]/div[1]/div[1]/div");
	public static By SearchDelete = By.className("sc-bwzfXH gxAMEF");
	public static By SearchButton = By.className("_yufu0rNaN");
	public static By NoSearchResult = By.className("_3j1YMd3zjL1xNt87XF8hqO");
	public static By LoginButton = By.className("_7byueq");
	public static By SearchSuggetions = By.xpath("/html/body/div[2]/div[2]/div[3]/div/div/div/div/div/div/div/div[2]/div/div[2]/div/div[1]/div[1]/div[2]/ul/li");
	public static By SearchResultDetails = By.className("_1l8BKJknPbTFydg6LnWWT1");
	public static By SearchResultList = By.className("qq-Pyd4MklQfqSfWC1B5j");
	public static By SearchBox1 = By.className("DyuNWRwk8LaMul8OtByVk");
}
