package com.testcases;

import org.openqa.selenium.support.ui.Sleeper;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.locators.Home_Page;
import com.methods.UserSearch;
import com.utils.BaseClass;

public class SearchWithLogin extends BaseClass{

	@Parameters({"Select", "email", "password", "SearchText"})
	@Test(priority=1)
	public void LoginAndSearch(String Select, String email, String password, String SearchText) throws Exception{
		UserSearch.Browser(Select);
		UserSearch.EmailFieldPresent(email);
		UserSearch.PasswordFieldPresent(password);
		UserSearch.LoginToApp();
		Thread.sleep(1000);
		UserSearch.SearchBox2();
		//UserSearch.MouseHoverOnSearch();
		UserSearch.PerformSearch(SearchText);
		UserSearch.ClickOnSearchButton();
		UserSearch.SearchResultPage();
	}
	
	public class SearchWithoutLogin extends BaseClass{

		@Parameters({"Select", "SearchText"})
		@Test(priority=2)
		public void LoginAndSearch(String Select, String SearchText) throws Exception{
			UserSearch.Browser(Select);
			UserSearch.LoginToApp();
			Thread.sleep(1000);
			UserSearch.SearchBox2();
			//UserSearch.MouseHoverOnSearch();
			UserSearch.PerformSearch(SearchText);
			UserSearch.ClickOnSearchButton();
			UserSearch.SearchResultPage();
		}
		
	}
}
