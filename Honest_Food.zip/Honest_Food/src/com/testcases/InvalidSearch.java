package com.testcases;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.methods.UserSearch;
import com.utils.BaseClass;

public class InvalidSearch extends BaseClass{

		@Parameters({"Select", "SearchText"})
		@Test(priority=4)
		public void EmptySearch(String Select, String SearchText) throws Exception{
			UserSearch.Browser(Select);
			UserSearch.SearchBox2();
			//UserSearch.MouseHoverOnSearch();
			UserSearch.PerformSearch(SearchText);
			UserSearch.VerifyNoSearchResults();
		}
		
		@Parameters({"Select", "SearchText"})
		@Test(priority=5)
		public void LongString(String Select, String SearchText) throws Exception{
			UserSearch.Browser(Select);
			UserSearch.SearchBox2();
			//UserSearch.MouseHoverOnSearch();
			UserSearch.PerformSearch(SearchText);
			UserSearch.VerifyNoSearchResults();
		}
}
