package com.testcases;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.methods.UserSearch;

public class SearchSuggetion {
	
	@Parameters({"Select", "SearchText"})
	@Test(priority=3)
	public void SearchSuggetion(String Select, String SearchText) throws Exception{
		UserSearch.Browser(Select);
		UserSearch.SearchBox2();
		//UserSearch.MouseHoverOnSearch();
		UserSearch.PerformSearch(SearchText);
		UserSearch.ClickOnSearchSuggetions();
		UserSearch.VerifySearchDetailsPage();
	}
	
	
}
