package com.testcases;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.methods.UserSearch;

public class DeleteSearchString {
	@Parameters({"Select", "SearchText"})
	@Test(priority=6)
	public void DeleteSearchString(String Select, String SearchText) throws Exception{
		//Step 1
		UserSearch.Browser(Select);
		//Step 2
		UserSearch.SearchBox2();
		//Step 3
		UserSearch.PerformSearch(SearchText);
		//Step 4
		UserSearch.ClickOnSearchSuggetions();
		//Step 5
		UserSearch.DeleteSearchAndVeirfy();
	}
	
	
}
